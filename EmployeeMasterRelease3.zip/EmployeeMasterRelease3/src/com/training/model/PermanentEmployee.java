package com.training.model;

import com.training.util.SalaryCalculator;

public class PermanentEmployee extends Employee{
	
	private String designation;
	
	private int rating;
	
	private SalaryCalculator calculator = new SalaryCalculator();
	
	public void updateRating( String feedback){
		
		if(feedback.equals("Excellent")){
			
			rating=1;
		}
		if(feedback.equals("Better")){
			
			rating =2;
		}
		if(feedback.equals("Good")){
			
			rating=3;
		}
		else{
			
			rating = 4;
		}
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public int getRating() {
		return rating;
	}

public void calculateSalary(int lossOfPay){
		
		System.out.println("inside PermanentEmployee class");
		
		
		this.takeHomeSalary = calculator.calculateSalary(lossOfPay, basicSalary);
		
		System.out.println("takeHomeSalary " +this.takeHomeSalary);
		
	}
	
}
