package com.lms.service;

import com.training.model.ContractEmployee;
import com.training.model.Employee;
import com.training.model.PermanentEmployee;

public class LeaveService {
	
	public static void main(String arg[]){
		
		PermanentEmployee pe = new PermanentEmployee();
		
		pe.setEmployeeId(1000);
		pe.setName("Kumar");
		pe.setSalary(100000);
		pe.setDesignation("Developer");
		
		pe.updateCasualLeave(2);
		
		pe.updateRating("Excellent");
		
		ContractEmployee ce = new ContractEmployee();
		ce.setEmployeeId(5000);
		ce.setName("Ravi");
		ce.setSalary(150000);
		
		ce.updateCasualLeave(2);
		ce.renewContract("Excellent");			
		
		manageLeaves(pe);		
		manageLeaves(ce);
		
		
		Employee e = pe;
		
		//e.updateRating("Excellent");
		
		Employee e1 = ce;
		
		//e1.renewContract("Excellent")
		

		
	}
	
	
	public static void manageLeaves(Employee employee){
		
		
		employee.updateCasualLeave(1);
		
	}
	
	
	

}
