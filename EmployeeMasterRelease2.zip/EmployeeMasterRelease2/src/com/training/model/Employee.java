package com.training.model;

public class Employee {
	
	protected int employeeId;
	
	protected  String name;
	
	protected int casualLeaves=20;
	
	protected float salary;
	
	 
	public int getEmployeeId() {
		return employeeId;
	}



	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public float getSalary() {
		return salary;
	}



	public void setSalary(float salary) {
		this.salary = salary;
	}



	public int getCasualLeaves() {
		return casualLeaves;
	}



	public void updateCasualLeave(int leaveApplied) {
		
		if (leaveApplied >casualLeaves) {
			
			System.out.println("You have insufficient leave balance");
		}
		else {
			this.casualLeaves = this.casualLeaves-leaveApplied;
		
			System.out.println("You have " + casualLeaves+ " causal leaves");
		
		}
		
	}

	
	
	public void calculateSalary(int daysPresent){
		
		System.out.println("inside employee class");
	}
	

}
