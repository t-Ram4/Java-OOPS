package com.lms.service;

import com.training.model.Employee;

public class LeaveService {
	
	public static void main(String arg[]){
		
		Employee employee = new Employee();
		
		employee.employeeId=1000;
		employee.name="Kumar";
		employee.designation = "Developer";
		employee.salary = 50000;
		employee.causalLeaves=20;
		
		
		employee.updateCaualLeave(2);
		employee.updateCaualLeave(1);
		employee.causalLeaves=40;
		employee.updateCaualLeave(1);
		
	}

}
