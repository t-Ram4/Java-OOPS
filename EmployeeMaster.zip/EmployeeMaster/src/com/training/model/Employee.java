package com.training.model;

public class Employee {
	
	public int employeeId;
	
	public  String name;
	
	public int causalLeaves;
	
	public String designation;
	
	public float salary;
	
	 
	public void updateCaualLeave(int leaveApplied) {
		
		if (leaveApplied > causalLeaves) {
			
			System.out.println("You have insufficient leave balance");
		}
		else {
			this.causalLeaves = this.causalLeaves-leaveApplied;
		
			System.out.println("You have " + causalLeaves+ " causal leaves");
		
		}
		
	}

	
	
	
	

}
