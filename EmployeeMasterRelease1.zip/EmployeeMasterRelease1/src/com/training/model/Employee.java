package com.training.model;

public class Employee {
	
	public int employeeId;
	
	public  String name;
	
	private int causalLeaves=20;
	
	private int carryForward;
	
	public String designation;
	
	public float salary;
	
	
	public void carryForwardLeaves( int leavesToCarryForward){
		
		
		carryForward = leavesToCarryForward;
		
		
	}
	
	 
	public void updateCaualLeave(int leaveApplied) {
		
		if (leaveApplied > (causalLeaves+carryForward)) {
			
			System.out.println("You have insufficient leave balance");
		}
		else {
			this.causalLeaves = this.causalLeaves-leaveApplied;
		
			System.out.println("You have " + causalLeaves+ " causal leaves");
		
		}
		
	}

	
	
	
	

}
