package com.training.model;

public class Employee {
	
	protected int employeeId;
	
	protected  String name;
	
	protected int causalLeaves=20;
	
	protected float basicSalary;
	
	protected float takeHomeSalary;
	
	 
	public int getEmployeeId() {
		return employeeId;
	}



	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public float getBasicSalary() {
		return basicSalary;
	}



	public void setBasicSalary(float salary) {
		this.basicSalary = salary;
	}



	public int getCausalLeaves() {
		return causalLeaves;
	}



	public void updateCaualLeave(int leaveApplied) {
		
		if (leaveApplied > causalLeaves) {
			
			System.out.println("You have insufficient leave balance");
		}
		else {
			this.causalLeaves = this.causalLeaves-leaveApplied;
		
			System.out.println("You have " + causalLeaves+ " causal leaves");
		
		}
		
	}

	
	
	public void calculateSalary(int lossOfPay){
		
		System.out.println("inside employee class");
	}
	

}
