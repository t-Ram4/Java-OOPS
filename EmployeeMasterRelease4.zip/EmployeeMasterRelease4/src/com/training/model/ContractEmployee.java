package com.training.model;

public class ContractEmployee extends Employee{
	
	private int contractPeriodInDays;
	
	private boolean isRenew;
	
	public void renewContract(String feedback){
		
		
		if(feedback.equals("excellent") || feedback.equals("better")){
			
			this.isRenew = true;
		}
		
		
	}
	

}
