package com.training.performance.service;

import com.training.model.Appraisable;
import com.training.model.PermanentEmployee;

public class PerformanceManagementService {
	
	public static void main(String arg[]){
		
		Appraisable a = new PermanentEmployee();
		
		a.doPerformanceAppraisal("Excellent");

	}

}
